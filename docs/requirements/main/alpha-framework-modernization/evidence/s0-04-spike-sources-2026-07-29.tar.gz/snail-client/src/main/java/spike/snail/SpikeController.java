package spike.snail;

import com.aizuda.snailjob.client.job.core.enums.AllocationAlgorithmEnum;
import com.aizuda.snailjob.client.job.core.enums.TriggerTypeEnum;
import com.aizuda.snailjob.client.job.core.openapi.SnailJobOpenApi;
import com.aizuda.snailjob.common.core.enums.JobBlockStrategyEnum;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpikeController {

    private final SpikeJob spikeJob;

    public SpikeController(SpikeJob spikeJob) {
        this.spikeJob = spikeJob;
    }

    @PostMapping("/spike/create-trigger")
    public Map<String, Object> createAndTrigger() {
        Long jobId = SnailJobOpenApi.addClusterJob()
                .setJobName("Alpha Spike Job")
                .setExecutorInfo("alphaSpikeJob")
                .setRouteKey(AllocationAlgorithmEnum.ROUND)
                .setTriggerType(TriggerTypeEnum.SCHEDULED_TIME)
                .setTriggerInterval(3_600)
                .setBlockStrategy(JobBlockStrategyEnum.DISCARD)
                .setExecutorTimeout(10)
                .setMaxRetryTimes(0)
                .setRetryInterval(1)
                .setDescription("S0-04 no-side-effect compatibility task")
                .execute();
        Boolean triggered = SnailJobOpenApi.triggerClusterJob(jobId).execute();
        return Map.of("jobId", jobId, "triggered", triggered);
    }

    @GetMapping("/spike/executions")
    public Map<String, Integer> executions() {
        return Map.of("executions", spikeJob.executions());
    }
}
