package spike.snail;

import com.aizuda.snailjob.client.job.core.annotation.JobExecutor;
import com.aizuda.snailjob.client.job.core.dto.JobArgs;
import com.aizuda.snailjob.model.dto.ExecuteResult;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.stereotype.Component;

@Component
@JobExecutor(name = "alphaSpikeJob")
public class SpikeJob {

    private final AtomicInteger executions = new AtomicInteger();

    public ExecuteResult jobExecute(JobArgs args) {
        return ExecuteResult.success(executions.incrementAndGet());
    }

    public int executions() {
        return executions.get();
    }
}
