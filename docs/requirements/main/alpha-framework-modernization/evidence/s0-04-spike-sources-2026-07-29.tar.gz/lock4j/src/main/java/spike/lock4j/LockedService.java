package spike.lock4j;

import com.baomidou.lock.annotation.Lock4j;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.stereotype.Service;

@Service
public class LockedService {

    private final AtomicInteger active = new AtomicInteger();
    private final AtomicInteger maxActive = new AtomicInteger();

    @Lock4j(keys = "#key", acquireTimeout = 100, expire = 2_000)
    public void hold(String key, long millis) throws InterruptedException {
        int current = active.incrementAndGet();
        maxActive.accumulateAndGet(current, Math::max);
        try {
            Thread.sleep(millis);
        } finally {
            active.decrementAndGet();
        }
    }

    @Lock4j(keys = "#key", acquireTimeout = 100, expire = 2_000)
    public void fail(String key) {
        throw new IllegalStateException("expected spike failure");
    }

    @Lock4j(keys = "#key", acquireTimeout = 0, expire = 300, autoRelease = false)
    public void holdUntilExpiry(String key) {
        // The lock intentionally remains until Redis expires it.
    }

    public int maxActive() {
        return maxActive.get();
    }

    public void reset() {
        active.set(0);
        maxActive.set(0);
    }
}
