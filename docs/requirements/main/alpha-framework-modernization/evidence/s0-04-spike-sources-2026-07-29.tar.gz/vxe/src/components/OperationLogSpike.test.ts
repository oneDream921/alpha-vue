import { mount } from '@vue/test-utils'
import Antd from 'ant-design-vue'

import { COLUMN_STORAGE_KEY } from '../columnPreferences'
import OperationLogSpike from './OperationLogSpike.vue'

describe('OperationLogSpike', () => {
  beforeEach(() => window.localStorage.clear())

  it('coexists with Ant Design controls and renders a VXE table', async () => {
    const wrapper = mount(OperationLogSpike, {
      global: { plugins: [Antd] },
      attachTo: document.body,
    })
    await wrapper.vm.$nextTick()

    expect(wrapper.find('[aria-label="搜索日志"]').exists()).toBe(true)
    expect(wrapper.find('.vxe-table').exists()).toBe(true)
    expect(wrapper.find('[data-testid="responsive-table"]').classes()).toContain(
      'table-band',
    )
    wrapper.unmount()
  })

  it('restores the persisted cross-lifecycle column layout', async () => {
    window.localStorage.setItem(
      COLUMN_STORAGE_KEY,
      '["username","status","createdAt"]',
    )
    const wrapper = mount(OperationLogSpike, {
      global: { plugins: [Antd] },
    })
    await wrapper.vm.$nextTick()

    expect(
      (wrapper.vm as unknown as { visibleKeys: string[] }).visibleKeys,
    ).toEqual(['username', 'status', 'createdAt'])
  })
})
