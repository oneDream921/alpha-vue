package spike.lock4j;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.baomidou.lock.LockTemplate;
import com.baomidou.lock.exception.LockException;
import java.time.Duration;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lock4jCompatibilityTest {

    @Autowired
    private LockTemplate lockTemplate;

    @Autowired
    private LockedService lockedService;

    @BeforeEach
    void reset() {
        lockedService.reset();
    }

    @Test
    void boot4CreatesLockTemplateAndEnforcesAcquireTimeout() throws Exception {
        assertThat(lockTemplate).isNotNull();
        ExecutorService pool = Executors.newFixedThreadPool(2);
        CountDownLatch started = new CountDownLatch(1);
        try {
            Future<?> holder = pool.submit(() -> {
                started.countDown();
                lockedService.hold("same", 500);
                return null;
            });
            started.await();
            Thread.sleep(100);

            assertThatThrownBy(() -> lockedService.hold("same", 10))
                    .isInstanceOf(LockException.class);
            holder.get();
            assertThat(lockedService.maxActive()).isEqualTo(1);
        } finally {
            pool.shutdownNow();
        }
    }

    @Test
    void exceptionReleasesLock() {
        assertThatThrownBy(() -> lockedService.fail("failure"))
                .isInstanceOf(IllegalStateException.class);

        org.junit.jupiter.api.Assertions.assertTimeoutPreemptively(
                Duration.ofSeconds(1),
                () -> lockedService.hold("failure", 10));
    }

    @Test
    void fixedLeaseExpiresWhenAutoReleaseIsDisabled() throws Exception {
        lockedService.holdUntilExpiry("lease");
        ExecutorService pool = Executors.newSingleThreadExecutor();
        try {
            Future<?> blocked = pool.submit(() -> lockedService.holdUntilExpiry("lease"));
            assertThatThrownBy(blocked::get)
                    .hasCauseInstanceOf(LockException.class);

            Thread.sleep(450);
            pool.submit(() -> lockedService.holdUntilExpiry("lease")).get();
        } finally {
            pool.shutdownNow();
        }
    }
}
