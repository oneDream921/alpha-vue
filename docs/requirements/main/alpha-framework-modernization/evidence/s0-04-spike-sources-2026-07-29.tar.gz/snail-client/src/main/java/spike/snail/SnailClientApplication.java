package spike.snail;

import com.aizuda.snailjob.client.starter.EnableSnailJob;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableSnailJob
@SpringBootApplication
public class SnailClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(SnailClientApplication.class, args);
    }
}
