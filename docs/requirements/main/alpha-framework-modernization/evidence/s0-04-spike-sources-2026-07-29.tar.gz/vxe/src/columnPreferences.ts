export const COLUMN_STORAGE_KEY = 'alpha:vxe-spike:operation-columns'

export type ColumnKey =
  | 'username'
  | 'module'
  | 'operation'
  | 'request'
  | 'status'
  | 'duration'
  | 'ipAddress'
  | 'traceId'
  | 'createdAt'

export const defaultColumnKeys: ColumnKey[] = [
  'username',
  'module',
  'operation',
  'request',
  'status',
  'duration',
  'ipAddress',
  'traceId',
  'createdAt',
]

export function loadColumnKeys(storage: Storage): ColumnKey[] {
  const raw = storage.getItem(COLUMN_STORAGE_KEY)
  if (!raw) return [...defaultColumnKeys]

  try {
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return [...defaultColumnKeys]
    const supported = parsed.filter((key): key is ColumnKey =>
      defaultColumnKeys.includes(key as ColumnKey),
    )
    return supported.length ? supported : [...defaultColumnKeys]
  } catch {
    return [...defaultColumnKeys]
  }
}

export function saveColumnKeys(storage: Storage, keys: ColumnKey[]) {
  storage.setItem(COLUMN_STORAGE_KEY, JSON.stringify(keys))
}
