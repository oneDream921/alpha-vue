import {
  COLUMN_STORAGE_KEY,
  defaultColumnKeys,
  loadColumnKeys,
  saveColumnKeys,
} from './columnPreferences'

describe('VXE column preferences', () => {
  beforeEach(() => window.localStorage.clear())

  it('uses the complete default layout when no preference exists', () => {
    expect(loadColumnKeys(window.localStorage)).toEqual(defaultColumnKeys)
  })

  it('persists a reduced layout across component lifecycles', () => {
    saveColumnKeys(window.localStorage, ['username', 'status', 'createdAt'])
    expect(window.localStorage.getItem(COLUMN_STORAGE_KEY)).toBe(
      '["username","status","createdAt"]',
    )
    expect(loadColumnKeys(window.localStorage)).toEqual([
      'username',
      'status',
      'createdAt',
    ])
  })

  it('ignores unsupported or malformed stored values', () => {
    window.localStorage.setItem(COLUMN_STORAGE_KEY, '["username","secret"]')
    expect(loadColumnKeys(window.localStorage)).toEqual(['username'])
    window.localStorage.setItem(COLUMN_STORAGE_KEY, '{broken')
    expect(loadColumnKeys(window.localStorage)).toEqual(defaultColumnKeys)
  })
})
