<script setup lang="ts">
import { SettingOutlined } from '@ant-design/icons-vue'
import { computed, ref, watch } from 'vue'
import { VxeColumn, VxeTable } from 'vxe-table'

import 'vxe-table/lib/style.css'

import {
  defaultColumnKeys,
  loadColumnKeys,
  saveColumnKeys,
  type ColumnKey,
} from '../columnPreferences'

type OperationRow = {
  id: number
  username: string
  module: string
  operation: string
  method: string
  requestUri: string
  status: number
  duration: number
  ipAddress: string
  traceId: string
  createdAt: string
}

const columnOptions: Array<{ key: ColumnKey; label: string }> = [
  { key: 'username', label: '用户' },
  { key: 'module', label: '模块' },
  { key: 'operation', label: '操作' },
  { key: 'request', label: '请求' },
  { key: 'status', label: '状态' },
  { key: 'duration', label: '耗时' },
  { key: 'ipAddress', label: 'IP 地址' },
  { key: 'traceId', label: 'Trace ID' },
  { key: 'createdAt', label: '时间' },
]

const rows: OperationRow[] = [
  {
    id: 1,
    username: 'admin',
    module: '用户管理',
    operation: '修改用户状态',
    method: 'PUT',
    requestUri: '/api/system/users/18/status',
    status: 1,
    duration: 36,
    ipAddress: '192.168.1.20',
    traceId: '9ad035b01a1b40a79cc99613fb590d10',
    createdAt: '2026-07-29 22:42:18',
  },
  {
    id: 2,
    username: 'operator',
    module: '文件管理',
    operation: '删除业务附件',
    method: 'DELETE',
    requestUri: '/api/files/982',
    status: 0,
    duration: 418,
    ipAddress: '10.0.0.15',
    traceId: 'bd79319f07a6481f948f694db0ea3dc4',
    createdAt: '2026-07-29 22:39:02',
  },
  {
    id: 3,
    username: 'admin',
    module: '系统配置',
    operation: '更新公开配置',
    method: 'PUT',
    requestUri: '/api/system/configs/site.title',
    status: 1,
    duration: 57,
    ipAddress: '192.168.1.20',
    traceId: '1cd549937cf84370b5544aa57ce93336',
    createdAt: '2026-07-29 22:31:44',
  },
]

const keyword = ref('')
const settingsOpen = ref(false)
const visibleKeys = ref<ColumnKey[]>(loadColumnKeys(window.localStorage))

const filteredRows = computed(() => {
  const query = keyword.value.trim().toLowerCase()
  if (!query) return rows
  return rows.filter((row) =>
    [row.username, row.module, row.operation, row.requestUri]
      .join(' ')
      .toLowerCase()
      .includes(query),
  )
})

function visible(key: ColumnKey) {
  return visibleKeys.value.includes(key)
}

function resetColumns() {
  visibleKeys.value = [...defaultColumnKeys]
}

watch(
  visibleKeys,
  (keys) => {
    if (keys.length) saveColumnKeys(window.localStorage, keys)
  },
  { deep: true },
)
</script>

<template>
  <section class="page">
    <div class="page-heading">
      <div>
        <p class="eyebrow">系统审计</p>
        <h1>操作日志</h1>
      </div>
      <a-button aria-label="刷新日志">刷新</a-button>
    </div>

    <div class="filter-band">
      <a-input
        v-model:value="keyword"
        allow-clear
        aria-label="搜索日志"
        placeholder="搜索用户、模块、操作或请求"
      />
      <a-button type="primary">搜索</a-button>
      <a-popover v-model:open="settingsOpen" trigger="click" placement="bottomRight">
        <template #content>
          <div class="column-settings">
            <div class="settings-title">
              <strong>显示列</strong>
              <a-button type="link" size="small" @click="resetColumns">
                恢复默认
              </a-button>
            </div>
            <a-checkbox-group v-model:value="visibleKeys">
              <a-checkbox
                v-for="item in columnOptions"
                :key="item.key"
                :value="item.key"
              >
                {{ item.label }}
              </a-checkbox>
            </a-checkbox-group>
          </div>
        </template>
        <a-button aria-label="列设置">
          <template #icon><SettingOutlined /></template>
          <span class="desktop-label">列设置</span>
        </a-button>
      </a-popover>
    </div>

    <div class="table-band" data-testid="responsive-table">
      <VxeTable
        :data="filteredRows"
        border
        stripe
        round
        height="100%"
        min-height="360"
        :sort-config="{ trigger: 'cell' }"
        :column-config="{ resizable: true }"
      >
        <VxeColumn
          v-if="visible('username')"
          field="username"
          title="用户"
          width="120"
          sortable
          fixed="left"
        />
        <VxeColumn
          v-if="visible('module')"
          field="module"
          title="模块"
          width="140"
          sortable
        />
        <VxeColumn
          v-if="visible('operation')"
          field="operation"
          title="操作"
          width="180"
        />
        <VxeColumn v-if="visible('request')" title="请求" width="300">
          <template #default="{ row }">
            <code>{{ row.method }}</code> {{ row.requestUri }}
          </template>
        </VxeColumn>
        <VxeColumn
          v-if="visible('status')"
          field="status"
          title="状态"
          width="100"
          align="center"
          sortable
        >
          <template #default="{ row }">
            <a-badge
              :status="row.status === 1 ? 'success' : 'error'"
              :text="row.status === 1 ? '成功' : '失败'"
            />
          </template>
        </VxeColumn>
        <VxeColumn
          v-if="visible('duration')"
          field="duration"
          title="耗时"
          width="110"
          align="right"
          sortable
        >
          <template #default="{ row }">{{ row.duration }} ms</template>
        </VxeColumn>
        <VxeColumn
          v-if="visible('ipAddress')"
          field="ipAddress"
          title="IP 地址"
          width="150"
        />
        <VxeColumn
          v-if="visible('traceId')"
          field="traceId"
          title="Trace ID"
          width="290"
        />
        <VxeColumn
          v-if="visible('createdAt')"
          field="createdAt"
          title="时间"
          width="190"
          sortable
        />
      </VxeTable>
    </div>
    <footer class="table-footer">
      <span>共 {{ filteredRows.length }} 条记录</span>
      <a-pagination :total="filteredRows.length" :page-size="10" size="small" />
    </footer>
  </section>
</template>
