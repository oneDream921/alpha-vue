<script setup lang="ts">
import { defineAsyncComponent } from 'vue'

const OperationLogSpike = defineAsyncComponent(
  () => import('./components/OperationLogSpike.vue'),
)
</script>

<template>
  <main class="app-shell">
    <header class="app-header flex-between">
      <div>
        <span class="product-mark">A</span>
        <strong>Alpha 管理端</strong>
      </div>
      <a-tag color="blue">VXE 单页试点</a-tag>
    </header>
    <OperationLogSpike />
  </main>
</template>
